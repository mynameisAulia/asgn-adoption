<?php
$conn = mysqli_connect("localhost", "root", "", "tb_data");
